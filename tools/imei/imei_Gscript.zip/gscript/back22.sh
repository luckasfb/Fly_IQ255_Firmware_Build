# CreateDir
mkdir /sdcard/backup_

# ddImage
dd if=/proc/mtd of=/sdcard/backup_/firmware.info
dd if=/dev/mtd/mtd0 of=/sdcard/backup_/preloader.img
dd if=/dev/mtd/mtd1 of=/sdcard/backup_/nvram.img
dd if=/dev/mtd/mtd2 of=/sdcard/backup_/seccnfg.img
dd if=/dev/mtd/mtd3 of=/sdcard/backup_/uboot.img
dd if=/dev/mtd/mtd4 of=/sdcard/backup_/boot.img
dd if=/dev/mtd/mtd5 of=/sdcard/backup_/recovery.img
dd if=/dev/mtd/mtd6 of=/sdcard/backup_/secstatic.img
dd if=/dev/mtd/mtd7 of=/sdcard/backup_/misc.img
dd if=/dev/mtd/mtd10 of=/sdcard/backup_/logo.img
dd if=/dev/mtd/mtd11 of=/sdcard/backup_/expdb.img

mount -o remount,rw -t yaffs2 /dev/block/mtdblock8 /system

cat /sdcard/Install/BackUp/yaffs_back_2.2/gen/mkyaffs2image > /system/bin/mkyaffs2image
chmod 4777 /system/bin/mkyaffs2image

/system/bin/mkyaffs2image /system /sdcard/backup_/system.img
/system/bin/mkyaffs2image /cache /sdcard/backup_/cache.img
/system/bin/mkyaffs2image /data /sdcard/backup_/data.img

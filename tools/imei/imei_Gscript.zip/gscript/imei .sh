echo  'AT+EGMR=1,7,"123456789012347"'>/dev/pttycmd1
echo 'AT+EGMR=1,10,"123456789023450"'>/dev/pttycmd1

